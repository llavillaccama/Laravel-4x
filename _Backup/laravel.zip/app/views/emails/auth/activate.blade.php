Hello {{ $username }},
Please activate your account using following link.
{{ $link }}