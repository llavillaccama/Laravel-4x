Hello {{ $username}}

New password: {{ $password }}

{{ $link }}