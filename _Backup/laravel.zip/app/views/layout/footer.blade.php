   	<!-- jQuery -->
    	{{ HTML::script('js/jquery.js') }}
    	<!-- Bootstrap Core JavaScript -->
    	{{ HTML::script('js/bootstrap.min.js') }}
    	<!-- Plugin JavaScript -->
    	{{ HTML::script('js/jquery.easing.min.js') }}
    	{{ HTML::script('js/classie.js') }}
    	{{ HTML::script('js/cbpAnimatedHeader.js') }}
    	<!-- Contact Form JavaScript -->
 
    	<!-- Custom Theme JavaScript -->
    	{{ HTML::script('js/freelancer.js') }}
    </body>

    </html>